# @gitaalekhyapaul/raziel-sdk-ts

Version 0.1.0 provides Node.js ESM and TypeScript declarations for Raziel signing
and authenticated identity lookup. Node.js 24.18.0 or newer is required.

## Current Scope

`createRazielClient(...).me()` signs `GET /api/agent/v1/me` under ADR-0020.
It checks the returned identity and audience against the caller's configured key.
The response is identity metadata, not permission to access data.

Access requests, operator approval, polling, issuance submission, cancellation,
and protected-query transport are not implemented in this release. The existing
capability and protected-request signing helpers remain available. They do not
contact a server or verify a proof.

This package has no runtime dependencies and no Protobuf runtime requirement.
It uses Node's native fetch and WebCrypto. Browser support is not claimed.

## Caller-Owned Signing

Supply an existing raw 32-byte Ed25519 public key and a signing function:

```ts
import {
  createRazielClient,
  type AgentSigner,
} from "@gitaalekhyapaul/raziel-sdk-ts";

export async function lookupIdentity(
  signer: AgentSigner,
  tokenProvider: () => Promise<string>,
) {
  const client = createRazielClient({
    baseUrl: "https://raziel.example.com",
    audience: "your-installation-trust-domain",
    tokenProvider,
    signer,
    timeoutMs: 10_000,
  });
  return client.me();
}
```

The signer contract is `{ publicKey: Uint8Array, sign(message): Promise<Uint8Array> }`.
`sign` signs the supplied framed bytes directly. Do not hash them first.
The client copies the public key and derives its SHA-256 thumbprint. It rejects
signatures that are not 64-byte byte arrays. The backend owns strict Ed25519
key and signature verification, token validity, and replay admission.

`createWebCryptoSigner({ publicKey, privateKey })` adapts an existing Ed25519
WebCrypto private key with sign usage. It does not generate, store, export,
recover, or rotate keys. The application owns key storage and token retrieval.
The legacy `createAgentIdentity()` helper still generates an in-memory key on
explicit invocation. The client never calls it or creates a replacement identity.

## Transport Contract

- `baseUrl` is an origin, with an optional trailing slash. Credentials, path
  prefixes, query strings, and fragments are rejected.
- HTTPS is required outside loopback. HTTP accepts `localhost`, IPv4 loopback,
  and IPv6 `::1` for local development or an SSH tunnel.
- `audience` is the configured installation trust domain, not the origin.
  It must contain 1-128 printable ASCII bytes.
- `tokenProvider` returns the canonical `rz1.<tokenId>.<secret>` token on each call.
  The token ID is 32 lowercase hexadecimal characters. The secret is canonical
  unpadded base64url encoding of 32 bytes. The client has no token cache.
- Every call uses a fresh 32-byte random nonce and current whole-second timestamp.
  The GET request has no body. Its signature covers the empty-body SHA-256 hash.
- No redirects, cookies, caching, or automatic retries are used. An injected
  `fetch` must honor the supplied RequestInit, including `redirect: "error"`.
- `timeoutMs` defaults to 10,000 and covers token retrieval, signing, transport,
  and body reading. A timeout aborts fetch and blocks a later send. Caller-owned
  token or signer promises cannot be canceled by this interface.
- The client accepts only HTTP 200 JSON with the exact six response fields.
  The public key and thumbprint must be canonical padded base64 for its own key.
  The expiry must be a canonical nonnegative decimal string within the Protobuf
  timestamp range. Responses are capped at 4,096 bytes.

`me()` returns this strict ProtoJSON shape, without decoding byte fields:

```ts
interface AgentMe {
  formatVersion: 1;
  agentId: string;
  publicKey: string;
  keyThumbprint: string;
  audience: string;
  tokenExpiresAtUnixSeconds: string;
}
```

`RazielClientError` exposes `code`, optional HTTP `status`, and `retryable`.
It accepts the public API error envelope `{ error: { code, retryable } }`.
401 maps to `NOT_AUTHORIZED`, 409 replay to `REQUEST_REPLAYED`, and 503 to
`SERVICE_UNAVAILABLE`. Retry metadata never triggers an automatic retry.
Unrecognized server bodies and provider, signer, or transport diagnostics are
not copied into errors. A timeout is an unknown outcome, not proof of rejection.

## Compatibility

`compatibility.json` records backend protocol revision `c0310a4`, ADR-0020, and
the public canonical vector references. The Rust agent-auth fixture is copied
into the test tree and checks exact message, key hash, body hash, and signature.
Public test fixtures are excluded from the npm tarball.

The full previous SDK surface is retained: `createAgentIdentity`,
`signCapabilityRequest`, `signProtectedRequest`, `verifyProtectedRequestSignature`,
canonical helpers, constants, and types. The legacy `RAZIEL_SDK_PACKAGE` value
remains `@raziel/sdk-ts`. `getSdkPackageInfo()` retains its M5 fields and values.
Use `RAZIEL_PUBLIC_SDK_PACKAGE` for this package's published name.

This release is intended for a pinned local tarball during backend migration.
No npm publication or complete M6 access workflow is claimed here.

## Development

Exact development pins are TypeScript 6.0.3, Node types 24.13.3, Vitest 4.1.10,
and Biome 2.5.4. Package scripts are `build`, `typecheck`, `test`, `lint`, and
`format:check`. `prepack` builds the declarations and ESM output.

An existing compatible Linux toolchain can validate a staging checkout without
installing dependencies. Mount the backend read-only at `/workspace` and this
package read-write at `/sdk`. Invoke the pinned binaries directly:

```sh
node /workspace/packages/sdk-ts/node_modules/typescript/bin/tsc \
  -p /sdk/tsconfig.build.json \
  --typeRoots /workspace/packages/sdk-ts/node_modules/@types

RAZIEL_BACKEND_ROOT=/workspace \
node /workspace/packages/sdk-ts/node_modules/vitest/vitest.mjs \
  run --root /sdk --config /sdk/vitest.config.mjs

node /workspace/node_modules/@biomejs/biome/bin/biome lint /sdk/src /sdk/test
```

The Vitest config uses that explicit optional backend path. It creates no links
into another repository. A normal standalone checkout uses its own installed
dev dependencies. There are no workspace dependencies or private server modules.

## License

MIT. The existing repository LICENSE is retained unchanged.
